/**
 * 
 */
 
 <script>
 
 
 let sum2 = (a,b) => a +b;
 alert(sum2(1,2));
 
 
 let double2 = n => n* 2;
 alert(double2(3));
 
 let sayHi = () => alert("Hello");
 sayHi();
 
 
 let age=prompt("What is your age.?",18);
 let welcome = (age < 18) ?
 		() => alert('Hello') :
 		() => alert("Greetings!");
 		
 welcome();
 
</script>