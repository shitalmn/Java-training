
public class Notes {

	public Notes() {
		// TODO Auto-generated constructor stub
	}

}
/*

		A		User - RAW data
				|
		B		UserDAO -> DBMS or its simulation - Kitchen
				|
			-------------------
			|				|
		C	UserService <-- business logic - FoodService
			|
		-----------------------
		|					|
	D	UserResource		ParcelCounter|TakeAway
		|  phone			|
	----------		-------------
	|							|
Client/customer					customer
	



*/