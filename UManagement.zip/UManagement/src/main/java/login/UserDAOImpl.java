package login;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class UserDAOImpl implements UserDAO {

	Connection conn; //global ref

	public UserDAOImpl() {
		// TODO Auto-generated constructor stub
		 System.out.println("DashboardServlet()");   	
	        try {
				Class.forName("com.mysql.jdbc.Driver");
				System.out.println("Database Driver loaded....");
				conn = DriverManager.getConnection("jdbc:mysql:///mysql","root","Shital@123");
			    System.out.println("Connected to the DB : "+conn);	
				  
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

	@Override

	
	
	
	
	
	
	
	
	
	public void saveData(User us) {
		// TODO Auto-generated method stub
		try {
			PreparedStatement pst = conn.prepareStatement("insert into userdata values (?,?,?)");
			pst.setString(1, us.getName());
			pst.setString(2, us.getEmail());
			pst.setString(3, us.getPassword());
		
			int row  = pst.executeUpdate();
			System.out.println("user created : "+row);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public User findUser(String primaryKeyEmail) {

		User theUser = null;

		try {
			Statement st = conn.createStatement();
			System.out.println("statement created.."+st);
			ResultSet rs = st.executeQuery("SELECT * FROM userdata where email='"+primaryKeyEmail+"'");
			System.out.println("Query fired...got the result...");
			
			
			if(rs.next()) {
				theUser = new User();
				theUser.setName(rs.getString(1));
				theUser.setEmail (rs.getString(2));
				theUser.setPassword ( rs.getString(3));
				
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return theUser;
	}

	@Override
	public List<User> findAllUsers() {
		ArrayList<User> userList = new ArrayList();

		try {
			Statement st = conn.createStatement();
			System.out.println("statement created.."+st);
			ResultSet rs = st.executeQuery("SELECT * FROM userdata");
			System.out.println("Query fired...got the result...");
			
			
			while(rs.next()) {
				User theUser = new User();
				theUser.setName(rs.getString(1));
				theUser.setEmail (rs.getString(2));
				theUser.setPassword ( rs.getString(3));
				
				userList.add(theUser);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return userList;
	}

	@Override
	public void modifyUser(User us) {
		try {
			PreparedStatement pst = conn.prepareStatement("update userdata set name=?, paswword=? where email=?)");
			pst.setString(3, us.getEmail());
			pst.setString(1, us.getName());
			pst.setString(2, us.getPassword());
			
			int row  = pst.executeUpdate();
			System.out.println("User updated : "+row);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void removeUser(String primaryKeyEmail) {
		// TODO Auto-generated method stub
		try {
			PreparedStatement pst = conn.prepareStatement("delete from userdata where email=?)");
			pst.setString(1, primaryKeyEmail);
			int row  = pst.executeUpdate();
			System.out.println("User deleted : "+row);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
