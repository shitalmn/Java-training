package login;

import java.sql.*;  
  
public class Login {  
public static boolean validate(String email,String password){  
boolean status=false;  
try{  
Class.forName("com.mysql.cj.jdbc.Driver");  
Connection con=DriverManager.getConnection( "jdbc:mysql://localhost:3306/mysql","root","Shital@123");
      
PreparedStatement ps=con.prepareStatement("select * from userdata where email=? and password=?");  
ps.setString(1,email);  
ps.setString(2,password);  
      
ResultSet rs=ps.executeQuery();  
status=rs.next();  
          
}catch(Exception e){System.out.println(e);}  
return status;  
}  
}


