package login;
import java.util.List;

public interface UserDAO {

	
	void saveData(User us); //C
	
	User findUser(String primaryKeyEmail);
	
	List<User> findAllUsers();
	
	
	void modifyUser(User us); //U
	
	
	void removeUser(String primaryKeyEmail); //D
}




