package login;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
* Servlet implementation class DashboardServlet
*/
@WebServlet("/DashboardServlet")

public class DashboardServlet extends HttpServlet {
       
       Connection conn;
    public DashboardServlet() {
        super();
         //global ref
          //  System.out.println("RegistrationServlet()");          
     /*       try {
                Class.forName("com.mysql.jdbc.Driver");
                 conn =DriverManager.getConnection("jdbc:mysql:///mysql","root","Shital@123");
                  System.out.println("Connected to the DB : "+conn);     
                      
              } catch (ClassNotFoundException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
              } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
              }*/
    }

       
       protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
              
       }

       protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
              response.setContentType ("text/html");
        PrintWriter out = response.getWriter ();
        String email = request.getParameter ("email");
        try
        {
           /*
            PreparedStatement ps =conn.prepareStatement ("select * from userdata where email=?");
            ps.setString (1, email);
          
            out.print ("<table width=50% border=1 >");
            out.print ("<caption   style='font-size:20px; text-align:center; padding: 5px 10px; color:Red;'>User Details</caption>");
            ResultSet rs = ps.executeQuery ();
            /* Printing column names */
          /*  out.print ("</br></br>");
            ResultSetMetaData rsmd = rs.getMetaData ();
            int total = rsmd.getColumnCount ();
            out.print ("<tr>");
            for (int i = 1; i <= total; i++)
         {
             out.print ("<th   style='font-size:20px; text-align:center; padding: 5px 10px; color:black; background-color:grey'>" + rsmd.getColumnName (i) + "</th>");
         }
            out.print ("</tr>");
            /* Printing result */
           /* while (rs.next ())
         {
             out.print ("<tr   style='font-size:20px; text-align:center; padding: 5px 10px; color:black; background-color:pink'><td>" + rs.getString (1) + "</td><td>" +  rs.getString (2) + " </td><td>" + rs.getString (3) + " </td><tr>" );
         }
            out.print ("</table>");*/
        
        UserDAO usDao = new UserDAOImpl();
        
        usDao.findAllUsers();
        
        }
        catch (Exception e2)
        {
            e2.printStackTrace ();
        }
       /* finally
        {
            out.close ();
        }*/
    }
       

}
