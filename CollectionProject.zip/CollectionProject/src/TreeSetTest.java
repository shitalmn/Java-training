import java.util.Iterator;
import java.util.LinkedList;
import java.util.TreeSet;

public class TreeSetTest {

	public static void main(String[] args) {
		System.out.println("Creating the content....");
		ChemicalElements ele1 = new ChemicalElements("Hydrogen","H",1,1.00797f);
		ChemicalElements ele2 = new ChemicalElements("Beryllium","Be",4,9.01218f);
		ChemicalElements ele3 = new ChemicalElements("Nitrogen","N",7,14.0067f);
		ChemicalElements ele4 = new ChemicalElements("Neon","N",10,20.179f);
		ChemicalElements ele5 = new ChemicalElements("Chromium","Cr",24,51.996f);
		
		System.out.println("Content is creaeted....");
		
		System.out.println("Creating container....");
		TreeSet<ChemicalElements> chemEle = new TreeSet<ChemicalElements>();
		System.out.println("Container is ready....");
		
		System.out.println("Adding the 1 element....");
		chemEle.add(ele1);
		
		System.out.println("Adding the 2 element....");
		chemEle.add(ele2);
			
		System.out.println("Adding the 3 element....");
		chemEle.add(ele3);
		
		System.out.println("Adding the 4 element....");
		chemEle.add(ele4);
		
		System.out.println("Adding the 5 element....");
		chemEle.add(ele5);
		
		System.out.println("---> Now iterating over the container <---");
		
		Iterator<ChemicalElements> iterator =  chemEle.iterator();
		
		while(iterator.hasNext()) {
			ChemicalElements theEle = iterator.next();
			System.out.println("Element : "+theEle);
		}
	}
	
		
}

class ChemicalElements implements Comparable<ChemicalElements>
{
	String atomicName;
	String atomicSymbol;
	int atomicNumber;
	float atomicMass;
	public ChemicalElements(String atomicName, String atomicSymbol, int atomicNumber, float atomicMass) {
		super();
		this.atomicName = atomicName;
		this.atomicSymbol = atomicSymbol;
		this.atomicNumber = atomicNumber;
		this.atomicMass = atomicMass;
	}
	@Override
	public String toString() {
		return "ChemicalElements [atomicName=" + atomicName + ", atomicSymbol=" + atomicSymbol + ", atomicNumber="
				+ atomicNumber + ", atomicMass=" + atomicMass + "]";
	}
	@Override
	public int compareTo(ChemicalElements o) {
		// TODO Auto-generated method stub
		System.out.println("comparing"+atomicNumber+"with"+o.atomicNumber);
		return Integer.compare(atomicNumber, o.atomicNumber);
	}

	
	
	
	

}