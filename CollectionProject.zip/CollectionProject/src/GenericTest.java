
public class GenericTest {

}
