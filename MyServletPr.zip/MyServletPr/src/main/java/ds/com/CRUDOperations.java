package ds.com;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

/**
 * Servlet implementation class CRUDOperations
 */
@WebServlet("/CRUDOperations")
public class CRUDOperations extends GenericServlet {
	private static final long serialVersionUID = 1L;
       
	Connection con=null;
    public CRUDOperations() {
        super();
        try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql","root","dinesh2001");
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

	
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		String value = request.getParameter("submit");
		String[] pmName=request.getParameterValues("pmName");
		System.out.println("working");
		for(int i=0;i<pmName.length;i++) {
		 System.out.println(pmName[i]);	
		}
	}
	
}
