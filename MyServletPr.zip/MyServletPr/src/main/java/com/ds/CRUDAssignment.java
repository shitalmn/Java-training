package com.ds;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

/**
 * Servlet implementation class CRUDAssignment
 */
@WebServlet("/CRUDAssignment")
public class CRUDAssignment extends GenericServlet {
	private static final long serialVersionUID = 1L;
       
    Connection con=null;
    public CRUDAssignment() {
        super();
        try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql","root","dinesh2001");
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
    }

	
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
	    String country =  request.getParameter("countryName"); //read this HTML tag's value
	    PrintWriter pw = response.getWriter();
	    try {
			Statement st = con.createStatement();
			System.out.println("statement created.."+st);
			ResultSet rs = st.executeQuery("SELECT * FROM MYCOUNTRIES");
			System.out.println("Query fired...got the result...");
			
			pw.println("<form action='CRUDOperations'>");
			pw.println("<TABLE border=5 cellspacing=5 cellpadding=5>");
			
			pw.println("<TH>Country</TH>");
			pw.println("<TH>Capital</TH>");
			pw.println("<TH>Prime Minister</TH>");
			pw.println("<TH>Population</TH>");
			pw.println("<TH>Currency</TH>");
			
			pw.println("<TR>");
			pw.println("<TD><input type=text name='countryName'></TD>");
			pw.println("<TD><input type=text name='capitalName'></TD>");
			pw.println("<TD><input type=text name='pmName'></TD>");
			pw.println("<TD><input type=text name='population'></TD>");
			pw.println("<TD><input type=text name='currency'></TD>");
			pw.println("<TD><input type=submit name=submit style='font-size:16px; text-align:center; padding: 15px 32px; color:white; background-color:blue' value='Add'></TD>");
			pw.println("</TR>");
			
			

			while(rs.next()) {
				pw.println("<TR>");
				
				String foundCountryName = rs.getString(1);
				String foundCapitalName = rs.getString(2);
				String foundPrimeMinister = rs.getString(3);
				
				String foundPopulation = rs.getString(4);
				String foundCurrency = rs.getString(5);
				
				
				pw.println("<TD style='font-size:20px; text-align:center; padding: 5px 10px; color:black; background-color:pink'>"+foundCountryName+"</TD>");
				pw.println("<TD style='font-size:20px; text-align:center; padding: 5px 10px; color:black; background-color:pink'>"+foundCapitalName+"</TD>");
				pw.println("<TD ><input style='font-size:20px; text-align:center; padding: 5px 10px; color:black; background-color:pink' type=text name='pmName' value='"+foundPrimeMinister+"'></TD>");
				pw.println("<TD style='font-size:20px; text-align:center; padding: 5px 10px; color:black; background-color:pink'>"+foundPopulation+"</TD>");
				pw.println("<TD style='font-size:20px; text-align:center; padding: 5px 10px; color:black; background-color:pink'>"+foundCurrency+"</TD>");
				
				pw.println("<TD><input type=submit name=submit style='font-size:16px; text-align:center; padding: 15px 32px; color:white; background-color:green' value='Edit'>   </TD>");
				pw.println("<TD><input type=submit name=submit style='font-size:16px; text-align:center; padding: 15px 32px; color:white; background-color:red' value='Delete'> </TD>");

				pw.println("</TR>");

			}
			pw.println("</TABLE>");
			pw.println("</form>");

			
			
			rs.close();
			st.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
