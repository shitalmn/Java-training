package com.ds;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.TreeMap;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

/**
 * Servlet implementation class FindCountry
 */
@WebServlet("/FindCountry")
public class FindCountry extends GenericServlet {
	Country c1 = new Country("India", "New Delhi", "Mr. Narendra Modi", "136.64 Crores", "Rs");
	Country c2 = new Country("Pakistan", "Islamabad", "Mr. Imran Khan", "21.66 Crores", "Pakistani Rupee");
	Country c3 = new Country("China", "Beijing", "Mr. Xi Jinping", "139.77 Crores", "Yuan");
	Country c4 = new Country("England", "London", "Mr. Boriss Johnson", "6.66 Crores", "Pound Sterling");
	Country c5 = new Country("America", "Washington DC", "Mr. Joe Biden", "32.82 Crores", "USD");
	
	TreeMap<String,Country> countryMap = new TreeMap<String,Country>();

	
	private static final long serialVersionUID = 1L;
       
    
    public FindCountry() {
        super();
        countryMap.put("IND", c1);
		countryMap.put("PAK", c2);
		countryMap.put("CHI", c3);
		countryMap.put("ENG", c4);
		countryMap.put("USA", c5);

    }

	
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		String country=request.getParameter("countryName");
		PrintWriter pw=response.getWriter();
		if(countryMap.containsKey(country)) {
			pw.println("<h2>The Capital of " + country + " is " + countryMap.get(country).getCapital() );
		}
		
	}

}
