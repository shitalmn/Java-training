package com.ds;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
* Servlet implementation class ServletA
*/
@WebServlet("/A")
public class ServletA extends HttpServlet {
       
    public ServletA() {
        super();
        // TODO Auto-generated constructor stub
    }

       
       protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
              response.setContentType("text/html");
              
              PrintWriter pw = response.getWriter();
              Country cntObj1 = new Country("India", "New Delhi", "mr.narendra modi", "136.04 crores", "Rs");
              request.setAttribute("indObj", cntObj1);
              pw.println("<h1> Servlet A is invoked  "+cntObj1.hashCode()+"</h1>");
              pw.println("<h1> Servlet A is invoked  "+cntObj1.getName()+"</h1>");
              
              RequestDispatcher rd = request.getRequestDispatcher("/B");
              rd.include(request, response);
              
              pw.println("<h3> Servlet A is back </h3>");
       }

       
       protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       
       }

}

