package com.ds;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

@WebServlet("/InsertCountryServlet")
public class InsertCountryServlet extends GenericServlet {
	private static final long serialVersionUID = 1L;
       
    Connection con=null;
    public InsertCountryServlet() {
        super();
        try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql","root","dinesh2001");
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
    }

	
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		String country=req.getParameter("countryName");
		String capital=req.getParameter("capital");
		String prime=req.getParameter("prime");
		String population=req.getParameter("population");
		String currency=req.getParameter("currency");
		
		try {
			PreparedStatement ps=con.prepareStatement("INSERT INTO MYCountries values (?,?,?,?,?);");
			ps.setString(1, country);
			ps.setString(2, capital);
			ps.setString(3, prime);
			ps.setString(4, population);
			ps.setString(5, currency);
			if(ps.executeUpdate()!=0) {
				System.out.println("<h2>Details have been inserted into DB....");
			}
			else {
				System.out.println("<h2>Could not be able insert into DB....");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
