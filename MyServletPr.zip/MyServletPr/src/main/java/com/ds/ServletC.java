package com.ds;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
* Servlet implementation class ServletA
*/
@WebServlet("/C")
public class ServletC extends HttpServlet {
       
    public ServletC() {
        super();
        // TODO Auto-generated constructor stub
    }

       
       protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
              response.setContentType("text/html");
              
              PrintWriter pw = response.getWriter();
              
              Country cntObj3 = (Country) request.getAttribute("indObj");
              cntObj3.setName(cntObj3.getName().toLowerCase());
              pw.println("<h3> Servlet B is invoked  "+cntObj3.hashCode()+"</h3>");
              pw.println("<h3> Servlet B is invoked  "+cntObj3.getName()+"</h3>");
              pw.println("<h3> Servlet C is invoked </h3>");
              
              
             
       }

       
       protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       
       }

}

