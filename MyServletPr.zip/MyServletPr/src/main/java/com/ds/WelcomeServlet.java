package com.ds;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

/**
 * Servlet implementation class WelcomeServlet
 */
@WebServlet("/WelcomeServlet")
public class WelcomeServlet extends GenericServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see GenericServlet#GenericServlet()
     */
    public WelcomeServlet() {
       System.out.println("Welcome servlet().....ctor");
    }

	
	public void init(ServletConfig config) throws ServletException {
		System.out.println("inti()");
	}

	
	public void destroy() {
		System.out.println("destroy()");
	}

	/**
	 * @see Servlet#service(ServletRequest request, ServletResponse response)
	 */
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		System.out.println("Service");
		response.setContentType("text/html");
		String hostAdd=request.getRemoteHost();
		int hostPort=request.getRemotePort();
		PrintWriter pw=response.getWriter();
		pw.println("<!DOCTYPE html>\n"
				+ "<html>\n"
				+ "<head>\n"
				+ "    \n"
				+ "    <title>Page Title</title>\n"
				+ "    \n"
				+ "</head>\n"
				+ "<body>");
		for(int i=1;i<=6;i++) {
			pw.println("<h"+i+">Welcome to world of java servlets</h"+i+"> ");
		}
		pw.println("</body>\n"
				+ "</html>");
	}

}
