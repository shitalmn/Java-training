package com.ds;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
* Servlet implementation class ServletA
*/
@WebServlet("/B")
public class ServletB extends HttpServlet {
       
    public ServletB() {
        super();
        // TODO Auto-generated constructor stub
    }

       
       protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
              response.setContentType("text/html");
              
              PrintWriter pw = response.getWriter();
              Country cntObj2 = (Country) request.getAttribute("indObj");
              cntObj2.setName(cntObj2.getName().toUpperCase());
              pw.println("<h2> Servlet B is invoked  "+cntObj2.hashCode()+"</h2>");
              pw.println("<h2> Servlet B is invoked  "+cntObj2.getName()+"</h2>");
          
              
              
              RequestDispatcher rd = request.getRequestDispatcher("/C");
              rd.include(request, response);
              
              pw.println("<h3> Servlet B is back </h3>");
       }

       
       protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       
       }

}

