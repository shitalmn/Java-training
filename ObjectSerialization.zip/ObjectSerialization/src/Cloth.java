import java.io.Serializable;

public class Cloth implements Serializable
{
	private String type;
	private int quantity;
	private transient int  amount;
	private String color;
	
	
	



	public Cloth(String type, int quantity, int amount, String color) {
		super();
		this.type = type;
		this.quantity = quantity;
		this.amount = amount;
		this.color = color;
	}






	@Override
	public String toString() {
		return "Cloth [ type=" + type + ", quantity=" + quantity + ", amount=" + amount + ", color=" + color + "]";
	}






	void printCloth()
	{
		System.out.println("---------cloth Info-------------");
		System.out.println("cloth type"+type);
		System.out.println("cloth color"+color);
		System.out.println("cloth quantity"+quantity);
		System.out.println("cloth amount"+ amount);
		
	}
	

}
