
package ExceptionFiles;

public class JeansIsNotAvailable extends RuntimeException {

	

	public  JeansIsNotAvailable(String message) {
		// TODO Auto-generated constructor stub
	}
	
}