package ExceptionFiles;

public class BeltColorNotAvailableException extends RuntimeException {

	

	public BeltColorNotAvailableException(String message) {
		// TODO Auto-generated constructor stub
	}
	
}