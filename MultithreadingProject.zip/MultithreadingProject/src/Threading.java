

public class Threading {
	public static void main(String[] args) {
		//1. extend from java.lang.Thread class
		//2. override public void run()  method
		//3. create the object of your sub class
		//4. invoke the start() method of it, which would 
		// execute the run() method of it
		
		RailwayReservation r1 = new RailwayReservation("reservation1 - "); //3
		RailwayReservation r2 = new RailwayReservation("\tReservation2 - "); //3
		RailwayReservation r3 = new RailwayReservation("\t\tReservation3 - "); //3
		RailwayReservation r4 = new RailwayReservation("\t\t\tReservation4 - "); //3

		r1.start();
		r2.start();
		r3.start();
		r4.start();
		
		
	}
}

class RailwayReservation extends Thread //1
{
	String reservation;
	
	RailwayReservation(String r) {
		reservation = r;
	}
	
	public void run() { //2. overriridng is always optional
		for (int i = 1; i < 25; i++) {
			System.out.println(reservation+ " "+i);
		}
	}
}


