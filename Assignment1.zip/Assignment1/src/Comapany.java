import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;




public class Comapany {
        public static void main(String[] args) {
		
        	Scanner sc= new Scanner(System.in);
        	
        System.out.println("How many departments u want enter.?");
        int dpNo = sc.nextInt() ;
		Department d = new Department();
		for(int i=0;i<dpNo;i++)
		{
			String dName = sc.nextLine();
			d.setName(dName);
			ArrayList<String> al=new ArrayList<String>(); 
			if (al.contains(dName))
			{
				
				DepartmentNameIsAlreadyPresent duplicateDNameEx = new DepartmentNameIsAlreadyPresent("Department name is already present plz add new one");
				throw duplicateDNameEx;
			}
			else
			{
				d.getDepId(dName);
				System.out.println("dname"+d.getName());
				String dLoc = sc.nextLine();
				d.setLocation(dLoc);
				System.out.println("dloaction"+d.getLocation());
			}
		}
		
		
        }
		
}

class Department
{
	private String name;
	private String location;
	private int depID=0;
	private int noOfEmp=0;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	public int getNoOfEmp() {
		return noOfEmp;
	}
	public void setNoOfEmp(int noOfEmp) {
		this.noOfEmp = noOfEmp;
	}
	
	int getDepId(String name)
	{
		
		if(depID==0)
		{
			depID=10;
		}
		else
		{
			depID = depID+10;
		}
		return 0;
	}
	
	ArrayList e1 = new 
	



}