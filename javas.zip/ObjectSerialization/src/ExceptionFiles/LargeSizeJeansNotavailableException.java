
package ExceptionFiles;

public class LargeSizeJeansNotavailableException extends RuntimeException {

	

	public  LargeSizeJeansNotavailableException(String message) {
		// TODO Auto-generated constructor stub
	}
	
}