
public class EmployeeAlreadyExistsException extends Exception{

	public EmployeeAlreadyExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
