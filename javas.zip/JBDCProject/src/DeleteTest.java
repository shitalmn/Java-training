
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class DeleteTest {
	public static void main(String[] args) throws EmployeeAlreadyExistsException, EmployeeNotFoundException
	{
		
		//1. WE KNOW THE DRIVER - org.hsqldb.jdbc.JDBCDriver.class
		//2. REGISTER THIS DRIVER
		try {
			System.out.println("Registering driver...");    
			DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
			System.out.println("Driver registered....");
			
			System.out.println("Trying to connect to the DB");
			Connection conn = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/xdb", "SA", "");
			
			System.out.println("Connected to the DB : "+conn);
			
		
			
			
			Scanner scan1 = new Scanner(System.in);
			System.out.println("Enter employee number : ");
			int eno = scan1.nextInt();
			
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("select * from employee where empno="+eno);
			
			if(rs.next()) {
				
				System.out.println("trying to make a Prepared statment");
				PreparedStatement pst = conn.prepareStatement("DELETE FROM EMPLOYEE WHERE EMPNO=?");
				System.out.println("Prepared Statement created : "+pst);
			
				
				pst.setInt(1, eno);//fill up the question mark with its value
			
				System.out.println("Trying to execute thE DELETE statement....");
				int rows = pst.executeUpdate();
				
				System.out.println("delete Statement executed, deleted the records :..."+rows);
				
				pst.close();	conn.close();
			}
			else {
				EmployeeNotFoundException ex = new EmployeeNotFoundException("This employee number does not exists : "+eno);
				throw ex;
			}
			
			
				
			
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		    
	}
}
