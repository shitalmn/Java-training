
public class EmployeeNoNotFoundException extends RuntimeException{


	public EmployeeNoNotFoundException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

	
}
