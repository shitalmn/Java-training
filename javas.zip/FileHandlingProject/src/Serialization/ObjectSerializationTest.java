package Serialization;



import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;



public class ObjectSerializationTest {

		public static void main(String[] args) {
			
			BankAccount ba = new BankAccount(101,"Julie1",50001,12341,"Savings");
			BankAccount ba1 = new BankAccount(102,"Julie2",50002,12342,"Current");
			BankAccount ba2 = new BankAccount(103,"Julie3",50003,12343,"Credit");
			BankAccount ba3 = new BankAccount(104,"Julie4",50004,12344,"Current");
			BankAccount ba4 = new BankAccount(105,"Julie5",50005,12345,"Savings");
			System.out.println("Object created...");
			
			try {
				FileOutputStream fout  = new FileOutputStream("C:\\Users\\Student\\Desktop\\javas\\Day1\\src\\bank1.txt");
				System.out.println("File is ready...");
				
				ObjectOutputStream oos = new ObjectOutputStream(fout);
				System.out.println("Object stream is ready....");
				
				System.out.println("Trying to store the object...");
				oos.writeObject(ba);
				oos.writeObject(ba1);
				oos.writeObject(ba2);
				oos.writeObject(ba3);
				oos.writeObject(ba4);
				
				System.out.println("Object stored....");
				
				oos.close();
				fout.close();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
				
			
		}
	
	/*	public static void main(String[] args) throws IOException {
		
		
		BankAccount ba = new BankAccount(101,"Julie",50000,1234,"Savings");
		
		System.out.println("ba "+ba.balance);
		
		FileWriter fout  = new FileWriter("/Users/apple/bank.txt");
		PrintWriter pw = new PrintWriter(fout);
		
		pw.println(ba.accountNumber);
		pw.println(ba.accountHolder);
		pw.println(ba.balance);
		
		pw.close();
		fout.close();
		
	}
	*/
}