import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileHandlingTest2 {

	FileInputStream fin;
	
	FileHandlingTest2(String fileName)
	{
		try
		{
			System.out.println("Trying to open the file");
			fin = new FileInputStream(fileName);
		}
		catch(FileNotFoundException e)
		{
			System.out.println("Problem 1"+e);
		}
			System.out.println("File is open........");
	}		
	
			void readFileData()
			{
				try
				{
					byte b = (byte) fin.read(); // read 1st letter
					while(b!=-1) // -1 means end of file
					{
						System.out.print((char)b);
						b = (byte)fin.read(); // read succesive letters from position 2
						Thread.sleep(10); // pause 10ms
						
					}
				}
				catch(IOException e)
				{
					System.out.println("Problem 2"+e);
				}
				catch(InterruptedException e)// by thread.sleep
				{
					System.out.println("Problem 1"+e);
				}
			}
			

			void closeFile()
			{
				try {
					System.out.println("Trying to close the file");
					fin.close();
					System.out.println("File is closed........");
				}
				catch(IOException e)
				{
					System.out.println("Problem 1"+e);
				}
				
			}
		
			
		public static void main(String[] args) {
			
			FileHandlingTest2 t2 = new FileHandlingTest2("C:\\Users\\Student\\Desktop\\javas\\Day1\\src\\new1.txt");
			t2.readFileData();
			t2.closeFile();
			
		}
			
	
}
