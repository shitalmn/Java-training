import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;


public class FileCreationTest {

	public static void main(String[] args) {
		
	
		try {
			System.out.println("Trying to create a file.......");
			FileOutputStream fout = new FileOutputStream("C:\\Users\\Student\\Desktop\\javas\\Day1\\src\\new1.txt",true);
			System.out.println("File is created");
			
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter your data here......");
			String str = sc.nextLine();
			
			byte byteArray [] = str.getBytes();
			System.out.println("Converted the string into byte array.........");
			
			fout.write(byteArray);
			System.out.println("byte array is written to the file........");
			
			fout.close();
			System.out.println("File is closed....");
		}
		catch(FileNotFoundException e)
		{
			System.out.println("Problem 1"+e);
		}
		catch(IOException e)
		{
			System.out.println("Problem 2"+e);
		}
		
	}
}
