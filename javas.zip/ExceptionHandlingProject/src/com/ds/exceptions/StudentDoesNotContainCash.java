package com.ds.exceptions;

public class StudentDoesNotContainCash extends RuntimeException {

	public StudentDoesNotContainCash(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

		
}
