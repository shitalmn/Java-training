
public class Bank {

	public static void main(String[] args) {
		
		System.out.println("Banking started.............");
		BankAccount  baObj1 = new BankAccount();
		BankAccount  baObj2 = new BankAccount();
	
		baObj1.setBankAccount(1234, "Abc", 50000);
		baObj2.setBankAccount(1235, "xyz", 70000);
		
		baObj1.printBankAccount();
		baObj2.printBankAccount();
		
		
		System.out.println("Transfer initiated");
		float transactionAmount = 6000;
		baObj1.deposit(transactionAmount);
		baObj2.withdraw(transactionAmount);
		System.out.println("Transferred.....");
		
		baObj1.printBankAccount();
		baObj2.printBankAccount();
		
	}
}

class BankAccount
{
	int accountNumber;
	String accountHolderName;
	double balance;
	
	
	void setBankAccount(int x, String y, double z)
	{
		System.out.println("setBankAccount(int,string,double)");
		accountNumber = x;
		accountHolderName=y;
		balance = z;
		
	}
	
	double calculateSimpleInterest(float rateOfInterest, int period)
	{
		double simpleInterest = (balance * rateOfInterest * period)/100.0f;
		return simpleInterest;
	}

	
	void withdraw(double amountToWithdraw)
	{
		System.out.println("withdrawing....... "+amountToWithdraw);
		balance = balance + amountToWithdraw;
		
	}
	
	void deposit(double amountToDeposit)
	{
		System.out.println("depositing........"+amountToDeposit);
		balance = balance + amountToDeposit;
		
	}
	
	double getBalance()
	{
		return balance;
	}
	
	void printBankAccount()
	{
		System.out.println("ACNO"+accountNumber);
		System.out.println("ACNAME"+accountHolderName);
		System.out.println("ACBAL"+balance);
		System.out.println("----------------------");
	}
}