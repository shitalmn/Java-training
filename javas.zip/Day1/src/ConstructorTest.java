
public class ConstructorTest {
	public static void main(String[] args) 
	{
		Post postObj = new Post(101,"post1","This is interesting post1");
		postObj.createPost();
		Post postObj2 = new Post(102,"post2","This is interesting post2");
		postObj2.createPost();
		Post postObj3 = new Post(103,"post3","This is interesting post3");
		postObj3.createPost();
		postObj3 = new Post(104,"post4","This is interesting post3.1");
		postObj3.createPost();
	    System.out.println("post obj"+ postObj2);
	}
}

class Post
{
	private int postId;
	private String postName;
	private String postContent;
	
	/*Post(int a, String b,String c)
	{
		postId = a;
		postName = b;
		postContent = c;
		
	}*/
	
	



	public Post(int postId, String postName, String postContent) {
		super();
		this.postId = postId;
		this.postName = postName;
		this.postContent = postContent;
	}

	@Override
	public String toString() {
		return "Post [postId=" + postId + ", postName=" + postName + ", postContent=" + postContent + "]";
	}
	void createPost()
	{    
		
		System.out.println(" Post Id is  "+postId);
		System.out.println("Post Name is  "+postName);
		System.out.println("Post Content is \" "+postContent+"\"");
		
	}

}