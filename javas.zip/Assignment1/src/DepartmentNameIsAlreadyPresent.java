
public class DepartmentNameIsAlreadyPresent extends RuntimeException  {
	
	public DepartmentNameIsAlreadyPresent(String message) {
		// TODO Auto-generated constructor stub
	}
	
}
