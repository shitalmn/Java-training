//first.java

public class Greeting
{
	public static void main(String args[])
	{
		System.out.println("Hello java, How are you........????");
	}
}