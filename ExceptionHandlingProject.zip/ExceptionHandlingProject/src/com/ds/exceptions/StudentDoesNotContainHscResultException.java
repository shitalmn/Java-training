package com.ds.exceptions;

public class StudentDoesNotContainHscResultException extends Exception
{
	public StudentDoesNotContainHscResultException(String msg) {
		super(msg);
	}
}