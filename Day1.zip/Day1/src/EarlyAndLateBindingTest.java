

public class EarlyAndLateBindingTest {
	public static void main(String[] args) {
	
		Doctor1 d = new Doctor1();
		d.diagnose(); // d.Doctor.diagnose() - binding at compile time - early binding 
		
		Surgeon1 s = new Surgeon1();
		s.diagnose(); // s.Surgeon.diagnose()  
		
		HeartSurgeon1 hs = new HeartSurgeon1();
		hs.diagnose(); // hs.HeartSurgeon.diagnose();
		
		// d.diagnose, s.diagnose, hs.diagnose
		
		
		if(d instanceof Doctor1) {
			System.out.println("Yes, d is pointing to a Doctor");
		}
		
		if(s instanceof Doctor1) {
			System.out.println("Yes, s is pointing to a Doctor");
		}
		
		if(hs instanceof Doctor1) {
			System.out.println("Yes, hs is pointing to a Doctor");
		}
		
		System.out.println("================");
		
		
		Doctor1 ref = d;
		
		ref.diagnose(); //late - ref.Doctor.diagnose()
		
		ref = s;
		
		ref.diagnose(); //late - ref.Surgeon.diagnose()
		
		ref = hs;
		
		ref.diagnose(); //late - ref.HeartSurgeon.diagnose()
		
		
	}
}

class Doctor1
{
	void diagnose() //overridden - hidden
	{
		System.out.println("Doctor: diagnose()...ENT checkup..");
	}
}

class Surgeon1 extends Doctor1
{
	void diagnose() //overriding
	{
		System.out.println("Surgeon: diagnose()...CT scan checkup..");
	}
}

class HeartSurgeon1 extends Surgeon1
{
	void diagnose()
	{
		System.out.println("HeartSurgeon: diagnose()...ECG scan checkup..");
	}
}
