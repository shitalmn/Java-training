
public class FunctionTestType {

	public static void main(String args[])
	{
		
		Calculator myCalci = new Calculator();
		myCalci.fun1();
		myCalci.fun2(10,20.4f,56.80);
		double output = myCalci.fun3('A',5,4);
		System.out.println("Output"+output);
		double distance = myCalci.fun4();
		System.out.println("Distance"+distance);
		
	}
	
	
	
}


class Calculator
{
	void fun1()
	{
		System.out.println("fun1 is doing some activity");
		System.out.println("--------------------------");
		
	}
	
	void fun2(int x, float y,double z)
	
	{
		System.out.println("fun2 is doing some activity");
		System.out.println("x"+x);
		System.out.println("y"+y);
		System.out.println("z"+z);
		System.out.println("--------------------------");
		
	}
	
	double fun3(int x, float y,double z)
	
	{
		System.out.println("fun3 is doing some activity");
		System.out.println("x="+x+"y="+y+"z="+z);
	
		System.out.println("--------------------------");
		
		return x+y+15.87;
	}
	
	double fun4()
	
	{
		System.out.println("fun4 is doing some activity");
		
		
		return 186000.519 *480;
	}



}