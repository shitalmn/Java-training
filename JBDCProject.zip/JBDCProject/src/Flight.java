
public class Flight {

	String flightName;
	int flightNo;
	String source;
	String destination;
	public Flight(int flightNo) {
		super();
		this.flightNo = flightNo;
	}
	public Flight(String flightName, int flightNo) {
		super();
		this.flightName = flightName;
		this.flightNo = flightNo;
	}
	public Flight(String flightName, int flightNo, String source, String destination) {
		super();
		this.flightName = flightName;
		this.flightNo = flightNo;
		this.source = source;
		this.destination = destination;
	}
	
	public int getFlight()
	{
		return 0;
	}
	
	public void getSource()
	{
		System.out.println("source method");
	}
}
