
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileCharacterBasedTest {
	public static void main(String[] args) {
		try
		{
			System.out.println("Trying to open the file");
			FileReader fin = new FileReader("C:\\Users\\Student\\Desktop\\javas\\Day1\\src\\new1.txt");
			System.out.println("File is open........");
			int i= (byte) fin.read(); // read 1st letter
			while(i!=-1) // -1 means end of file
			{
				System.out.print((char)i);
				i = (byte)fin.read(); // read succesive letters from position 2
				Thread.sleep(10); // pause 10ms
				
			}
			System.out.println("Trying to close the file");
			fin.close();
			System.out.println("File is closed........");
		}
		catch(FileNotFoundException e)
		{
			System.out.println("Problem 1"+e);
		}
		catch(IOException e)
		{
			System.out.println("Problem 2"+e);
		}
		catch(InterruptedException e)// by thread.sleep
		{
			System.out.println("Problem 1"+e);
		}
	}
	
}
