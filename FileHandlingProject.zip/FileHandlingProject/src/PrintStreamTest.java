import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

public class PrintStreamTest {

	public static void main(String[] args) {
		
		FileOutputStream fout;
		try
		{
			fout = new FileOutputStream("C:\\Users\\Student\\Desktop\\javas\\Day1\\src\\new2.txt");
			
			//PrintStream ps = new PrintStream(System.out);
			PrintStream ps = new PrintStream(fout);
			
			System.out.println("Print stream is ready.............");
			
			ps.println("Hello file1");
			ps.println("Hello file2");
			ps.println("Hello file3");
			ps.println("Hello file4");
			
			ps.close();
			fout.close();
			
			
		} catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
		
	}
}
