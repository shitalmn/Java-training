
public class RollNoNotFoundException extends RuntimeException{


	public RollNoNotFoundException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
	
}
